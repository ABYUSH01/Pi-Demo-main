declare interface Window {
  Pi: any;
}
